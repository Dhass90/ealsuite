<?php
require "php/connect.php";
session_start();
if(!isset($_SESSION['user'])){
    echo "<script> window.location.replace('index.php')</script>";
    exit(); 
   
}

$c="select * from customer";
$result = mysqli_query($conn, $c);

$num=mysqli_num_rows($result);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
            height: 100%;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .content {
            margin-left: 250px; 
            padding: 20px;
            width: 100%;
        }

    </style>
</head>
<body>


    <div class="sidebar">
        <h3>Admin Portal</h3>
        <a href="customer.php"><li>Customer Section</li></a>
        <a href="invoice.php"> <li>Invoice Section</li></a>
        <a href="php/logout.php">Logout</a>
    </div>
<div class="content"><center>
<h2>Adding new Invoice</h2>
<form action="php/add.php" method="post">
<input type="hidden" name="type" id="type" value="2" ><br><br>
   <label for="customer"> Select Customer   :     </label>
    <?php 
    echo '<select name="customer" id="customer" required>';
    if($num==0){
        echo '<option value="">No customer available</option>';
    }
    else{
    echo ' <option value="" disabled selected >Select Customer</option>';
    while($opt=mysqli_fetch_assoc($result)){

        $optid=$opt['cust_id'];
        $cust=$opt['name'];
        echo '<option value="' . $optid . '">' . $cust . '</option>';
    }
    }
    echo '</select>';
    ?>
    
    <br><br>
        <label for="date">Select Date   :  </label>
        <input type="date" name="date" id="date" required><br><br>
        <label for="amount">Enter Amount   :  </label>
        <input type="number  " name="amount" id="amount" required><br><br>
        <label for="status">Select Status   :  </label>
        <select name="status" id="status" required>
            <option value="1">Paid</option>
            <option value="2">Unpaid</option>
            <option value="0">Cancelled</option>
        </select>
        <br><br>

        <input type="submit" value="submit">

    </form>

    <h2><a href="view.php ?type=2">View the Invoice</a></h2>

    </center></div>

</body>
</html>