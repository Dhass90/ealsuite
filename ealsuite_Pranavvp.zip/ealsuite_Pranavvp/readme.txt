
1)Import the SQL file "ealsuite.sql" in the DataBase.
2) Edit the "connect.php"(ealsuite_Pranavvp/php/connect.php) line 2 'hostname','username','password' .
3)open "index.php"
4) Use the username and password below.
username:pranav
Password:1234
(You can Change the password and username by changing 'auth' table in 'ealsuite' DataBase)
5)In the 'admin.php' page select 'customer section' and 'invoice section'
6)In the 'customer section' you can add customer details.
7)In the 'View the Customers' section you can View and update customer details.
8)In the 'invoice section' you can add invoice details.
9)In the 'View the Invoice' section you can View and update Invoice details.
10) Logout




Additional details


Status value: 1=Paid,2=Unpaid,0=Cancelled

Request Type: 1=customer,2=invoice.
