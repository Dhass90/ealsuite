
<?php

session_start();
if(!isset($_SESSION['user'])){
    echo "<script> window.location.replace('index.php')</script>";
    exit(); 
   
}
#echo $_SESSION['user'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
            height: 100%;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .content {
            margin-left: 250px; 
            padding: 20px;
            width: 100%;
        }

    </style>
</head>
<body>


    <div class="sidebar">
        <h3>Admin Portal</h3>
        <a href="customer.php"><li>Customer Section</li></a>
        <a href="invoice.php"> <li>Invoice Section</li></a>
        <a href="php/logout.php">Logout</a>
    </div>

    <div class="content">
        <h1>Welcome </h1>
        <p>Choose a section from the sidebar to manage.</p>
    </div>

</body>
</html>
