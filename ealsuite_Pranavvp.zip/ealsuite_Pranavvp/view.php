<?php
require "php/connect.php";
session_start();
if(!isset($_SESSION['user'])){
    echo "<script> window.location.replace('index.php')</script>";
    exit(); 
   
}

$type=$_GET['type'];
#echo $type;

$auth_c="select * from customer ";
$result1 = mysqli_query($conn, $auth_c);
$num=mysqli_num_rows($result1);
$snum=0;

$invoice="SELECT * FROM invoice JOIN customer ON invoice.customer_id = customer.cust_id";
$result2 = mysqli_query($conn, $invoice);
$num2=mysqli_num_rows($result2);



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
            height: 100%;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .content {
            margin-left: 250px; 
            padding: 20px;
            width: 100%;
        }

    </style>
</head>
<body>


    <div class="sidebar">
        <h3>Admin Portal</h3>
        <a href="customer.php"><li>Customer Section</li></a>
        <a href="invoice.php"> <li>Invoice Section</li></a>
        <a href="php/logout.php">Logout</a>
    </div>
    <div class="content">

<?php if($type == 1)
{

    if($num == 0)
    {
        echo "<script>alert('No customer found');</script>";
     }
     else {
    
    
    ?>
    <table border ="1"><tr>
    <th>sl1</th><th>regno</th><th>name</th><th>phone</th><th>email</th><th>address</th><th>Option</th>
    
    </tr>
    <tbody>
    <?php 
    while($row = mysqli_fetch_array($result1)) {  
        $snum++;
        ?>
    
        <tr>
            <td><?php echo $snum; ?></td>
            <td><?php echo $row['cust_id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['phone']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><a href="php/edit.php?id=<?php echo $row['cust_id']; ?>">Edit</a></td>
            </tr>
            <?php } ?>
    
    </tbody>
    
    </table>
    
    <?php } 

}
else{


    if($num2 == 0)
    {
        echo "<script>alert('No Invoice found');</script>";
     }
     else {
    
    
    ?>
    <table border ="1"><tr>
    <th>sl1</th><th>Invoice_no</th><th>Customer</th><th>Date</th><th>Amount</th><th>Status</th><th>Option</th>
    
    </tr>
    <tbody>
    <?php 
    while($row = mysqli_fetch_array($result2)) {  
        $snum++;
        ?>
    
        <tr>
            <td><?php echo $snum; ?></td>
            <td><?php echo $row['invoice_id']; ?></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['date']; ?></td>
            <td><?php echo $row['amount']; ?></td>
            <td><?php
            if($row['status'] == '1')  {
                echo "Paid";
            }  elseif($row['status'] == '2'){
                echo "Unpaid";
            }else{
                echo "Cancelled";
            }
            ?></td>
            <td><a href="php/editinvoice.php?id=<?php echo $row['invoice_id']; ?>">Edit</a></td>
            </tr>
            <?php } ?>
    
    </tbody>
    
    </table>
    
    <?php } 


}
?>
    </div>
</body>
</html>