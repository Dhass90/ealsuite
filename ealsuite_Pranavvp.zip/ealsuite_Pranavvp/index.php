<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>login</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>
<body bgcolor="#575757"><center>
    <form action="php/login.php" method="post"> 

        <h1>Login Page</h1>
    <input type="text" name="username" id="username" placeholder="Enter Your Username" required>
    <br><br>
    <input type="password" name="password" id="password" placeholder="Enter Your Password" required>
    <br><br>
    <input type="submit" value="Submit">
    </form></center>
</body>

</html>