<?php
require "php/connect.php";
session_start();
if(!isset($_SESSION['user'])){
    echo "<script> window.location.replace('index.php')</script>";
    exit(); 
   
}

$auth_q="select * from customer ";
$result = mysqli_query($conn, $auth_q);
$num=mysqli_num_rows($result);
$snum=0;


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            height: 100vh;
            margin: 0;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
            height: 100%;
            position: fixed;
        }

        .sidebar a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
        }

        .sidebar a:hover {
            background-color: #575757;
        }

        .content {
            margin-left: 250px; 
            padding: 20px;
            width: 100%;
        }

    </style>
</head>
<body>


    <div class="sidebar">
        <h3>Admin Portal</h3>
        <a href="customer.php"><li>Customer Section</li></a>
        <a href="invoice.php"> <li>Invoice Section</li></a>
        <a href="php/logout.php">Logout</a>
    </div>
<div class="content"><center>
<h2>Adding new customer</h2>
<form action="php/add.php" method="post">
    <input type="hidden" name="type" id="type" value="1" >
        <label for="name">Enter Your name   : </label><input type="text" name="name" id="name" placeholder="Enter the Name of the Customer" required> <br>
        <label for="phone">Enter Your  Mobile Number  : </label><input type="text" name="phone" id="phone" placeholder="Enter the Mobile Number" required> <br>
        <label for="email">Enter Your Email   : </label><input type="email" name="email" id="email" placeholder="Enter the Email ID of the Customer" required> <br>
        <label for="Address">Enter Your Address   : </label><input type="text" name="address" id="address" placeholder="Enter the Address of the Customer" required> <br>
        <br><input type="submit" value="Submit"> <h2><a href="view.php ?type=1">View the Customers</a></h2>
    </form></center></div>

</body>
</html>