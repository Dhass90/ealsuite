<?php
$conn=mysqli_connect('localhost','root','','ealsuite');
if($conn!=true)
 {echo "connection failed";}

?>
