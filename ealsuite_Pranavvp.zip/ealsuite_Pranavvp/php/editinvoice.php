<?php
require 'connect.php';
$a=$_GET['id'];

$c="select * from customer";
$result2 = mysqli_query($conn, $c);



$num=mysqli_num_rows($result2);

$q="SELECT * FROM invoice JOIN customer ON invoice.customer_id = customer.cust_id where invoice_id=$a";
#echo $q;
$result = mysqli_query($conn, $q);
$value= mysqli_fetch_assoc($result);
$custid=$value['cust_id'];
$custname=$value['name'];
if(isset($_POST['edit'])){

    $customer=$_POST['customer'];
    $date=$_POST['date'];
    $amount=$_POST['amount'];
    $status=$_POST['status'];

    $q2="update invoice SET customer_id='$customer', date='$date', amount='$amount',status='$status' where invoice_id = $a";
    echo $q2;
    $result = mysqli_query($conn, $q2);
    echo "<script>alert('Change added Successfully');</script>";
    echo"<script>  window.location.replace('../invoice.php');</script>";

    
}




?>
<h2>Editing  customer</h2>
<form action="<?php $_PHP_SELF ?> " method="post">

        <input type="text" name="name" id="name" value="<?php echo $value['invoice_id'] ?>" disabled> <br> <?php 
    echo '<select name="customer" id="customer" required>';
    if($num==0){
        echo '<option value="">No customer available</option>';
    }
    else{
    echo ' <option value="'.$custid.'" aria-pressed="true" selected>'.$custname.'</option>';
    while($opt=mysqli_fetch_assoc($result2)){

        $optid=$opt['cust_id'];
        $cust=$opt['name'];
        echo '<option value="' . $optid . '">' . $cust . '</option>';
    }
    }
    echo '</select>';
    ?> <br>
        <input type="text" name="date" id="date" value="<?php echo $value['date'] ?>" required> <br>
        <input type="text" name="amount" id="amount" value="<?php echo $value['amount'] ?>" required> <br>
        <select name="status" id="status" required>
            <option value="<?php echo $value['status'] ?>"  selected aria-pressed="true" >
            <?php
            if($value['status'] == '1')  {
                echo "Paid";
            }  elseif($value['status'] == '2'){
                echo "Unpaid";
            }else{
                echo "Cancelled";
            }
            ?>
            </option>
            <option value="1">Paid</option>
            <option value="2">Unpaid</option>
            <option value="0">Cancelled</option>
        </select>
        
        
        <br>
        <input name="edit" id="edit" type="submit" value="Edit Customer">
    </form>
</body>
</html>


