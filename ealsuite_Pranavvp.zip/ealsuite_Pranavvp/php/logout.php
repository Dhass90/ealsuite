<?php
session_start();
session_destroy();



?>
<script>
    
    window.location.replace("../index.php");
</script>