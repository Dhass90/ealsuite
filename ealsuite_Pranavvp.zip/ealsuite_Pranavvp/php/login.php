<?php
require "connect.php";
$user=$_POST['username'];
$pass=$_POST['password'];

#echo $user,$pass;

$auth_q="select * from auth ";
$result = mysqli_query($conn, $auth_q);
$num=mysqli_num_rows($result);

echo $num;
$auth_data = mysqli_fetch_assoc($result);

$check = $auth_data['auth_username'];

if($user == $auth_data['auth_username'] && $pass == $auth_data['auth_password']){
    echo "<script>alert('Login Successfully');</script>";
    
    session_start();
    $_SESSION['user']=$user;
    echo $_SESSION['user'];
    echo "<script>window.location.href='../admin.php';</script>";
}
else{
    echo "<script>alert('Invalid Credential');</script>";
    echo"<script>  window.location.href='../index.php';</script>";
}





?>