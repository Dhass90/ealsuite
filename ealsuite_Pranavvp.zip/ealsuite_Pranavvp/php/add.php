<?php
require 'connect.php';


$type=$_POST['type'];


if($type==1) 
{
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    
    $q="insert into customer(name,phone,email,address) values('$name','$phone','$email','$address')";
    //echo $q;

    $result=mysqli_query($conn,$q);
    echo "<script>alert('Customer added Successfully');</script>";
    echo"<script>  window.location.replace('../customer.php');</script>";

}else {

    $cust=$_POST['customer'];
    $date=$_POST['date'];
    $date=$_POST['date'];
    $amount=$_POST['amount'];
    $status=$_POST['status'];
    $q="insert into invoice(customer_id,date,amount,status) values('$cust','$date','$amount','$status')";

    #echo $q;
    $result=mysqli_query($conn,$q);
    echo "<script>alert('Invoice added Successfully');</script>";
    echo"<script>  window.location.replace('../invoice.php');</script>";



}

?>