<?php
require 'connect.php';
$a=$_GET['id'];

$q="select * from customer where cust_id = $a";
$result = mysqli_query($conn, $q);
$value= mysqli_fetch_assoc($result);

if(isset($_POST['edit'])){

    $name=$_POST['name'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];
    $address=$_POST['address'];

    $q2="update customer SET name='$name', phone='$phone', email='$email',address='$address' where cust_id = $a";
    echo $q2;
    $result = mysqli_query($conn, $q2);
    echo "<script>alert('Change added Successfully');</script>";
    echo"<script>  window.location.replace('../customer.php');</script>";

    
}




?>


<!DOCTYPE html>
<head>
    <title>Customer</title>
</head>
<body>
<h2>Editing  customer</h2>
<form action="<?php $_PHP_SELF ?> " method="post">
    <input type="text" name="type" id="type" value="1" disabled hidden>
        <input type="text" name="name" id="name" value="<?php echo $value['name'] ?>"> <br>
        <input type="text" name="phone" id="phone" value="<?php echo $value['phone'] ?>"> <br>
        <input type="text" name="email" id="email" value="<?php echo $value['email'] ?>"> <br>
        <input type="text" name="address" id="address" value="<?php echo $value['address'] ?>"> <br>
        <input name="edit" id="edit" type="submit" value="Edit Customer">
    </form>

</body>
</head>
</html>
